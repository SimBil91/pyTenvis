from distutils.core import setup

setup(name='pyTenvis',
      version='1.0',
      py_modules=['pyTenvis'],
      )
